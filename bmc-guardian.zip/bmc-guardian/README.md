# BMC Guardian

Sensor-fault → warn/beep → grace period → auto-shutdown (with manual cancel and
manual shutdown) for Dell iDRAC, Lenovo XClarity (XCC) and Supermicro BMC,
on top of an existing `kube-prometheus-stack`.

## Short answer to "can Grafana do this?"

**Partly.** Your existing Prometheus + Grafana + Alertmanager handle three of the
four jobs out of the box:

| Job | Component | Already in your stack? |
|-----|-----------|------------------------|
| Read BMC/iDRAC sensors | a Redfish exporter (added here) | no — add one pod |
| Detect anomaly | Prometheus alert rules (`PrometheusRule`) | yes |
| Show warning / dashboard | Grafana | yes |
| Notify / route the alert | Alertmanager | yes |
| **Beep + count-down + cancel + power-off the server** | **a small action service (added here)** | **no** |

Grafana and Alertmanager can *fire* and *display* an alert, but neither can press
the power button on a server. Redfish/IPMI power control is a side-effecting
action, and a "warn → wait → cancel? → shutdown" workflow needs state (a running
count-down that a human can interrupt). That logic lives in a ~350-line service
called **guardian-controller** included here. So: **keep the Grafana stack you
have, add two pods.** You do *not* need a separate monitoring system.

## Data flow

```
                Redfish (HTTPS)
 Dell iDRAC  ─┐
 Lenovo XCC  ─┼─►  idrac_exporter ──scrape──►  Prometheus ──rules──► Alertmanager
 Supermicro  ─┘   (one pod, all 3)                  │                     │
                                                    │ /metrics            │ webhook
                                                    ▼                     ▼
                                                 Grafana          guardian-controller
                                              (dashboards)     ┌──────────────────────┐
                                                               │ 1. beep + warning UI │
                                                               │ 2. grace count-down  │
                                                               │ 3. CANCEL? (human)   │
                                                               │ 4. else Redfish      │
                                                               │    GracefulShutdown  │
                                                               │ + manual shutdown    │
                                                               └──────────┬───────────┘
                                                                          │ Redfish reset
                                                                          ▼
                                                            Dell / Lenovo / Supermicro
```

## Why `idrac_exporter`

`mrlhansen/idrac_exporter` speaks the vendor-neutral **Redfish** API and is
tested against Dell iDRAC, Lenovo XClarity and Supermicro BMC — exactly your
three boxes — so one exporter pod covers the whole fleet. It encodes health as
the metric *value*: `idrac_system_health{status="OK"} 0`, with Warning/Critical
as higher numbers, which the alert rules in `manifests/20-prometheusrule.yaml`
key off.

The PowerEdge XE9680 (8×GPU) runs hot, so the temperature rule matters; note that
iDRAC itself force-shuts-down at its own hard CPU-critical limit, but Guardian
lets you act *earlier* on your own policy and gives an operator the chance to
abort.

## Files

```
manifests/
  00-namespace.yaml
  10-idrac-exporter-secret.yaml      BMC read-only creds (EDIT THIS)
  11-idrac-exporter.yaml             exporter Deployment + Service + ConfigMap
  12-idrac-exporter-probe.yaml       Prometheus Operator Probe (multi-target scrape)
  20-prometheusrule.yaml             anomaly alert rules
  30-alertmanager-config.yaml        route the "arming" alerts to the controller
  40-guardian-secret.yaml            BMC power creds + policy (EDIT THIS)
  41-guardian-controller.yaml        controller Deployment + Service
  42-guardian-ingress.yaml           optional: expose the operator console
controller/
  app.py                             the action service
  requirements.txt
  Dockerfile
  guardian-config.example.yaml       documented policy/host config
```

## Deploy

```bash
# 0. edit the two secret files with your BMC IPs + credentials
# 1. build & push the controller image (or use your registry/CI)
docker build -t YOUR_REGISTRY/guardian-controller:0.1.0 controller/
docker push  YOUR_REGISTRY/guardian-controller:0.1.0
# set that image in manifests/41-guardian-controller.yaml

# 2. apply (assumes kube-prometheus-stack in namespace 'monitoring',
#    with its Prometheus selecting PrometheusRule/Probe across namespaces —
#    the default for the Helm chart)
kubectl apply -f manifests/00-namespace.yaml
kubectl apply -f manifests/10-idrac-exporter-secret.yaml
kubectl apply -f manifests/11-idrac-exporter.yaml
kubectl apply -f manifests/12-idrac-exporter-probe.yaml
kubectl apply -f manifests/20-prometheusrule.yaml
kubectl apply -f manifests/30-alertmanager-config.yaml
kubectl apply -f manifests/40-guardian-secret.yaml
kubectl apply -f manifests/41-guardian-controller.yaml
# optional console ingress
kubectl apply -f manifests/42-guardian-ingress.yaml
```

Open the operator console (beep + count-down + cancel + manual buttons):

```bash
kubectl -n bmc-guardian port-forward svc/guardian-controller 8080:80
# http://localhost:8080
```

Grafana dashboard: import dashboard ID from the `idrac_exporter` repo
(`grafana/idrac_overview.json`) or build panels on the `idrac_*` metrics.

## Safety model (read this)

This service can power off production servers. The defaults are deliberately
conservative:

- **Graceful by default.** It sends Redfish `GracefulShutdown` (ACPI / clean OS
  shutdown), not `ForceOff`. Force is opt-in per action.
- **Arming is explicit.** Only alerts that carry the label
  `guardian_action: shutdown` start a count-down. Every other alert just shows in
  Grafana/Alertmanager. So a noisy "disk predicted-fail" warning will *not* power
  anything off unless you label it to.
- **Grace period + cancel.** Default 120 s count-down with an audible beep and a
  one-click **Cancel** before anything happens.
- **`dry_run` and `auto_shutdown: false`.** Start with `dry_run: true` globally,
  or `auto_shutdown: false` per host, so the workflow *only beeps and warns* and
  never actually powers off until you trust it.
- **Auth.** Set `GUARDIAN_TOKEN`; action endpoints and the webhook then require
  it. Add a `NetworkPolicy` so only Alertmanager and your operators reach it.
- **Single replica.** Incident state is in-memory; run one replica
  (`replicas: 1`, `Recreate`) so two pods don't both fire a shutdown.

> This is infrastructure tooling, not medical/safety-of-life equipment. Test the
> whole path with `dry_run: true` against one non-critical host before arming the
> XE9680.
